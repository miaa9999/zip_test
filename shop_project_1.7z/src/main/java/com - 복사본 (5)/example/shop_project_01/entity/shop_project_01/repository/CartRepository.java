package com.example.shop_project_01.entity.shop_project_01.repository;

import com.example.shop_project_01.entity.shop_project_01.entity.Cart;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CartRepository extends JpaRepository<Cart, Long> {
// <<<<<<< sh2
//     Cart findByUserAccount(UserAccount userAccount);
// =======

    Cart findByUserAccount_Username(String username);

}
