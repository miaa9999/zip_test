package com.example.shop_project_01.entity.shop_project_01.repository;

import com.example.shop_project_01.entity.shop_project_01.entity.Buy;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BuyRepository extends JpaRepository<Buy,Long> {
}
