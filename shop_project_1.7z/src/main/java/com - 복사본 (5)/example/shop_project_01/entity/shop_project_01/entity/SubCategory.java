package com.example.shop_project_01.entity.shop_project_01.entity;

import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;

@Data
public class SubCategory {
       @Id
       @GeneratedValue(strategy = GenerationType.IDENTITY)
       @Column(name = "sub_category_id")
       private Long subCategoryId;
       
       //       @ManyToOne
//       @JoinColumn(name = "mainCategoryId")
//       private MainCategory mainCategory;
       private String mainCategory;
       
       private String subCategoryName;
}
