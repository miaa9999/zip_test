package com.example.shop_project_01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopProject01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
