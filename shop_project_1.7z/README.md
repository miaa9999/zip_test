## 프로젝트 소개
온라인 쇼핑몰들을 참고하여 만든 사이트입니다.

## 멤버 구성
- 박지현 :
   - 관리자 : 판매내역 CRU
   - 사용자 : 상품 R, 포인트 충전 CRU , 로그인(회원가입), 상품구매 CRU, 장바구니 CRUD
  
- 안서현 :
   - 관리자 : 상품관리 CRU , 공지사항 CRUD , 회원관리 URD
   - 사용자 : 로그인(회원가입), 회원정보 RUD
  
## 개발환경
- 개발도구
  - IntelliJ
  - DBeaver
  - 
- 개발언어
  - JAVA
  - HTML
  - JavaScript
  - CSS

## ERD
![shop erd](https://github.com/miaa9999/shop_project_1/assets/162389738/b94ad9f1-68f2-4cb4-9e23-4b5d9d4e3171)
